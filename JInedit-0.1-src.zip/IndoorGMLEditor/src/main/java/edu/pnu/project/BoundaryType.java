package edu.pnu.project;

public enum BoundaryType {
	CellSpaceBoundary,
	Door
}
