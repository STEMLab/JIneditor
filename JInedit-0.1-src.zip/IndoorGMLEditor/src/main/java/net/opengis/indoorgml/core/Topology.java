package net.opengis.indoorgml.core;

import java.io.Serializable;

public enum Topology implements Serializable {
	CONTAINS, OVERLAPS, EQUALS, WITHIN, CROSSES, INTERSECTS 
}
